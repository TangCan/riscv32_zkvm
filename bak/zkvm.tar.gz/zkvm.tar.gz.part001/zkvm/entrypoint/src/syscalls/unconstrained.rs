#[cfg(any(target_os = "zkvm", target_os = "linux"))]
use core::arch::asm;

#[no_mangle]
pub fn syscall_enter_unconstrained() -> bool {
    #[allow(unused_mut)]
    let mut continue_unconstrained: u32;
    #[cfg(any(target_os = "zkvm", target_os = "linux"))]
    unsafe {
        syscall_asm_lateout!(
            crate::syscalls::ENTER_UNCONSTRAINED,
            continue_unconstrained,
        );
    }

    #[cfg(not(any(target_os = "zkvm", target_os = "linux")))]
    {
        eprintln!("Entering unconstrained execution block");
        continue_unconstrained = 1;
    }

    continue_unconstrained == 1
}

#[no_mangle]
pub fn syscall_exit_unconstrained() {
    #[cfg(any(target_os = "zkvm", target_os = "linux"))]
    unsafe {
        syscall_asm!(
            crate::syscalls::EXIT_UNCONSTRAINED,
        );
        unreachable!()
    }

    #[cfg(not(any(target_os = "zkvm", target_os = "linux")))]
    eprintln!("Exiting unconstrained execution block");
}
