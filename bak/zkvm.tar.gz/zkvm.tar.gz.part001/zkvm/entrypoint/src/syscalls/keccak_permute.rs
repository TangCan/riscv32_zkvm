#[cfg(any(target_os = "zkvm", target_os = "linux"))]
use core::arch::asm;

/// Executes the Keccak256 permutation on the given state.
///
/// ### Safety
///
/// The caller must ensure that `state` is valid pointer to data that is aligned along a four
/// byte boundary.
#[allow(unused_variables)]
#[no_mangle]
pub extern "C" fn syscall_keccak_permute(state: *mut [u64; 25]) {
    #[cfg(any(target_os = "zkvm", target_os = "linux"))]
    unsafe {
        syscall_asm!(
            crate::syscalls::KECCAK_PERMUTE,
            in("a0") state,
            in("a1") 0
        );
    }

    #[cfg(not(any(target_os = "zkvm", target_os = "linux")))]
    unreachable!()
}
