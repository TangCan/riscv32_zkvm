#[cfg(any(target_os = "zkvm", target_os = "linux"))]
use core::arch::asm;

/// Executes the SHA256 extend operation on the given word array.
///
/// ### Safety
///
/// The caller must ensure that `w` is valid pointer to data that is aligned along a four byte
/// boundary.
#[allow(unused_variables)]
#[no_mangle]
pub extern "C" fn syscall_sha256_extend(w: *mut [u32; 64]) {
    #[cfg(any(target_os = "zkvm", target_os = "linux"))]
    unsafe {
        syscall_asm!(
            crate::syscalls::SHA_EXTEND,
            in("a0") w,
            in("a1") 0
        );
    }

    #[cfg(not(any(target_os = "zkvm", target_os = "linux")))]
    unreachable!()
}
