cfg_if::cfg_if! {
    if #[cfg(any(target_os = "zkvm", target_os = "linux"))] {
        use core::arch::asm;
        use sha2::Digest;
        use crate::zkvm;
        use crate::{PV_DIGEST_NUM_WORDS, POSEIDON_NUM_WORDS};
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(target_os = "zkvm", feature = "verify"))] {
        use p3_field::PrimeField32;
    }
}

/// Halts the program with the given exit code.
///
/// Before halting, the syscall will commit to the public values.
#[allow(unused_variables)]
pub extern "C" fn syscall_halt(exit_code: u8) -> ! {
    #[cfg(any(target_os = "zkvm", target_os = "linux"))]
    unsafe {
        // When we halt, we retrieve the public values finalized digest.  This is the hash of all
        // the bytes written to the public values fd.
        let pv_digest_bytes =
            core::mem::take(&mut *core::ptr::addr_of_mut!(zkvm::PUBLIC_VALUES_HASHER))
                .unwrap()
                .finalize();

        #[cfg(feature = "blake3")]
        let pv_digest_bytes = pv_digest_bytes.as_bytes();

        // For each digest word, call COMMIT ecall.  In the runtime, this will store the digest
        // words into the runtime's execution record's public values digest.  In the AIR, it
        // will be used to verify that the provided public values digest matches the one
        // computed by the program.
        for i in 0..PV_DIGEST_NUM_WORDS {
            let word = u32::from_le_bytes(pv_digest_bytes[i * 4..(i + 1) * 4].try_into().unwrap());
            syscall_asm!(crate::syscalls::COMMIT, in("a0") i, in("a1") word);
        }

        cfg_if::cfg_if! {
            if #[cfg(feature = "verify")] {
                let deferred_proofs_digest = zkvm::DEFERRED_PROOFS_DIGEST.as_mut().unwrap();

                for i in 0..POSEIDON_NUM_WORDS {
                    let word = deferred_proofs_digest[i].as_canonical_u32();
                    syscall_asm!(crate::syscalls::COMMIT_DEFERRED_PROOFS, in("a0") i, in("a1") word);
                }
            } else {
                for i in 0..POSEIDON_NUM_WORDS {
                    syscall_asm!(crate::syscalls::COMMIT_DEFERRED_PROOFS, in("a0") i, in("a1") 0);
                }
            }
        }

        syscall_asm!(
            crate::syscalls::HALT,
            in("a0") exit_code
        );
        unreachable!()
    }

    #[cfg(not(any(target_os = "zkvm", target_os = "linux")))]
    unreachable!()
}
